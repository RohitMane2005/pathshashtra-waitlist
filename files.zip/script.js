let waitlistCount = 200;

function handleJoin() {
  const email = document.getElementById('emailInput').value.trim();
  if (!email || !email.includes('@')) {
    document.getElementById('emailInput').style.borderColor = '#ef4444';
    setTimeout(() => document.getElementById('emailInput').style.borderColor = '', 1500);
    return;
  }
  document.getElementById('formWrap').style.display = 'none';
  const msg = document.getElementById('successMsg');
  msg.style.display = 'block';
  msg.textContent = `🎉 You're on the list! We'll reach out soon with early access.`;
  waitlistCount++;
}

function handleJoin2() {
  const email = document.getElementById('emailInput2').value.trim();
  if (!email || !email.includes('@')) {
    document.getElementById('emailInput2').style.borderColor = '#ef4444';
    setTimeout(() => document.getElementById('emailInput2').style.borderColor = '', 1500);
    return;
  }
  document.getElementById('formWrap2').style.display = 'none';
  const msg = document.getElementById('successMsg2');
  msg.style.display = 'block';
  msg.textContent = `🎉 You're on the list! We'll reach out soon with early access.`;
  waitlistCount++;
}

// Intersection Observer for scroll-triggered fade-in animations
const observer = new IntersectionObserver((entries) => {
  entries.forEach(el => {
    if (el.isIntersecting) {
      el.target.style.opacity = '1';
      el.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.pain-card, .feature-card, .stat-card, .timeline-step').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(24px)';
  el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
  observer.observe(el);
});
